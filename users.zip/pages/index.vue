<template>
  <div>
    <ActionsComponent/>
    <div class="main">
      <table class="custom-table">
        <thead>
          <tr>
            <th v-for="header in headers" :key="header.value">{{ header.text }}</th>
            <th class="txt-actions">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in items" :key="item.series">
            <!-- <pre>{{ items }}</pre> -->
            <td>{{ item.initials }}</td>
            <td>{{ item.firstname }}</td>
            <td>{{ item.role.name }}</td>
            <td>{{ item.email }}</td>
            <td>{{ item.cellphone }}</td>
            <td>{{ item.documentIdentityType }}</td>
            <td>{{ item.documentNumber }}</td>
            <td>{{ item.status }}</td>
            <td class="buttons-table">
              <div @click="deleteItem(item)">
                <!-- <img class="menu-icon" src="../components/menu/svg/pdf.svg" width="30"> -->
              </div>
              <div @click="deleteItem(item)">
                <!-- <img class="menu-icon" src="../components/menu/svg/xml_file.svg" width="30"> -->
              </div>
              <div @click="deleteItem(item)">
                <!-- <img class="menu-icon" src="../components/menu/svg/cdr.svg" width="30"> -->
              </div>
              <router-link :to="`/items/${item.id}`">
                <!-- <img class="menu-icon" src="../components/menu/svg/eye.svg" width="30"> -->
              </router-link>

            </td>
          </tr>
        </tbody>
      </table>
      <div class="table__footer">
        <div class="table__footer__items table__footer__first">
          <span>Mostrar</span>
          <select v-model="itemsPerPage" @change="updatePagination" class="table__footer__select">
            <option v-for="option in footerProps.itemsPerPageOptions" :key="option" :value="option">{{ option }}</option>
          </select>
          <span>registros por página</span>
        </div>
        <div class="table__footer__items">
          <!-- <img src="@/components/menu/svg/arrowLeft.svg" width="20"> -->
          <span>{{ currentPage }}</span>
          <!-- <img src="@/components/menu/svg/arrowRight.svg" width="20"> -->
        </div>
        <div class="table__footer__items">
          <span>Ir a la página</span>
          <select v-model="currentPage" @change="updatePage" class="table__footer__select">
            <option >1</option>
          </select>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ActionsComponent from '~/components/ActionsComponent.vue';
export default {
  components: { ActionsComponent },
  async asyncData({ $axios }) {
    try {
      const pageNumber = 1;
      const pageSize = 10;
      const includeCurrentUser = false;
      const excludeInactiveUsers = false;

      const response = await $axios.get('https://ad.dev.arisale.com.pe/user-service/api/users', {
        params: {
          pageSize,
          pageNumber,
          includeCurrentUser,
          excludeInactiveUsers,
        },
        headers: {
          'accept': 'application/json',
          'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcmlhZCIsImV4cCI6MTcxMDk1MzU3MiwiaWF0IjoxNzA4MzYxNTcyLCJkYXRhIjoiUytuTkZGakE0R2w0aldqbEl3eGdDQmhiWjFOdTk4T2F2aGo0R2FydFpkWFBrL2xGZFZWQXVkdk00RCtHeVBZZSJ9.YItZcx3uIccVyeodYMRyXQN0d3ffZlxeT_kTbHPfb2M',
        },
      });

      const { items } = response.data;
      console.log(items);
      return { items };
    } catch (error) {
      console.error('Error al obtener los datos:', error);
      return { items: [] };
    }
  },
  data() {
    return {
      itemsPerPage: 10,
      currentPage: 1,
      items: [],
      headers: [
        { text: 'Foto', value: 'series' },
        { text: 'Nombre(s) y apellidos', value: 'sequence' },
        { text: 'Rol', value: 'type' },
        { text: 'Correo Electrónico', value: 'documentNumber' },
        { text: 'Teléfono', value: 'recipient' },
        { text: 'Tipo de doc.', value: 'date' },
        { text: 'Nº de doc', value: 'reason' },
        { text: 'Estado', value: 'associatedDocument' },
      ],
      footerProps: {
        itemsPerPageOptions: [10, 20, 30],
      }
    };
  },
  mounted() {
    // console.log(`The initial count `, this.items)
  },
  computed: {
    paginatedItems() {
      const startIndex = (this.currentPage - 1) * this.itemsPerPage;
      const endIndex = startIndex + this.itemsPerPage;
      return 3;
    },
    // const paginatedItems = computed(() => {
    //   const startIndex = (currentPage.value - 1) * itemsPerPage.value;
    //   const endIndex = startIndex + itemsPerPage.value;
    //   return items.value.slice(startIndex, endIndex);
    // });
    // totalPages() {
    //   return Math.ceil(this.items.length / this.itemsPerPage);
    // }
  },
  methods: {
    deleteItem(item) {
      // Implementar la funcionalidad de eliminación
    },
    updatePagination() {
      this.currentPage = 1;
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    // nextPage() {
    //   if (this.currentPage < this.totalPages) {
    //     this.currentPage++;
    //   }
    // },
    updatePage() {
      // No es necesario hacer nada, la asignación reactiva lo manejará
    }
  }
}
</script>
<style lang="scss" scoped>.main {
  margin: 1rem 0;
  background-color: white;
  border-radius: 10px;
}

.custom-table {
  width: 100%;
  border-collapse: collapse;
  color: #5c5b5a;
  font-size: 14px;

  th,
  td {
    border-top: 1px solid #e2e1e0;
    border-bottom: 1px solid #e2e1e0;
    padding: 8px;
    text-align: left;
  }
}
.pagination-text,
.pagination-controls {
  text-align: center;
  font-size: 14px;
}

.pagination-controls {
  margin-top: 8px;
  button {
    background-color: #4caf50;
    color: white;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
    border-radius: 4px;

    &:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
  }
}

.buttons-table {
  display: flex;
  justify-content: space-between;
}

.txt-actions {
  text-align: center !important;
}
.table__footer{
  padding: 1rem;
  display: flex;
  color: #5c5b5a;
  font-size: 14px;
  justify-content: space-between;
  &__items{
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  &__first{
    gap: 0.3rem;
  }
  &__select{
    padding: 0 1rem;
    border-radius: 5px;
    border: solid 1px #e2e1e0;
  }
}

</style>
